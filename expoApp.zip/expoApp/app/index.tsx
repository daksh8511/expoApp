import React from 'react';
import {Button, StyleSheet, Text, TextInput, View} from 'react-native';

const index = () => {
  return (
    <View style={styles.container}>
      <View style={styles.myheader}>
        <Text style={styles.signup}>SIGN UP</Text>
        <Text style={styles.logo}>Logo</Text>
      </View>
      <View style={styles.mynames}>
        <TextInput
          style={styles.namebox}
          placeholderTextColor="gray"
          placeholder="First Name"
        />
        <TextInput
          style={styles.namebox}
          placeholderTextColor="gray"
          placeholder="Last Name"
        />
      </View>
      <View>
        <TextInput
          placeholder="Enter Email"
          placeholderTextColor="gray"
          style={styles.input}
          keyboardType='email-address'
        />
      </View>
      <View>
        <TextInput
          placeholder="+91 1234567890"
          placeholderTextColor="gray"
          keyboardType="numeric"
          style={styles.input}
        />
      </View>
      <View>
        <TextInput placeholder='Address' placeholderTextColor='gray' style={styles.input} />
      </View>
      <View style={styles.city_zipcode}>
        <TextInput
          style={styles.namebox}
          placeholderTextColor="gray"
          placeholder="City Name"
        />
        <TextInput
          style={styles.namebox}
          placeholderTextColor="gray"
          placeholder="Zipcode"
          keyboardType='numeric'
        />
      </View>
      <Button title='submit' ></Button>
    </View>
  )
}

export default index

const styles = StyleSheet.create({
  container: {
    width: '100%',
    height: '100%',
    backgroundColor: 'white',
    padding: 25,
  },
  myheader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  signup: {
    fontSize: 30,
    fontWeight: 600,
    color: '#54A4DE',
  },
  mynames: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 25,
  },
  logo: {
    fontSize: 24,
    fontWeight: 500,
    color: '#129623',
  },
  namebox: {
    width: 180,
    height: 60,
    color: '#000',
    paddingHorizontal: 10,
    shadowColor: '#000',
    elevation: 2,
  },
  input: {
    width: '100%',
    height: 60,
    color: '#000',
    paddingHorizontal: 10,
    shadowColor: '#000',
    elevation: 2,
    marginTop: 10,
  },
  phonenumber : {
    width: '100%',
    height: 70,
    color: '#000',
    paddingHorizontal: 10,
    shadowColor: '#000',
    elevation: 2,
    marginTop: 10,
  },
  city_zipcode : {
    flexDirection: 'row',
    justifyContent: 'space-between',
  }
});
